import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

class Room {

    int roomNumber;
    String category;
    double price;
    boolean booked;

    Room(int roomNumber, String category, double price) {

        this.roomNumber = roomNumber;
        this.category = category;
        this.price = price;
        this.booked = false;
    }
}

class Booking {

    String customerName;
    int roomNumber;
    String category;
    double payment;

    Booking(String customerName,
            int roomNumber,
            String category,
            double payment) {

        this.customerName = customerName;
        this.roomNumber = roomNumber;
        this.category = category;
        this.payment = payment;
    }
}

class BackgroundPanel extends JPanel {
    private final Image backgroundImage;

    public BackgroundPanel(Image image) {
        this.backgroundImage = image;
        if (image == null) {
            setBackground(Color.LIGHT_GRAY);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}

public class HotelReservationSystem extends JFrame {

    ArrayList<Room> rooms = new ArrayList<>();
    ArrayList<Booking> bookings = new ArrayList<>();

    JTable table;
    DefaultTableModel model;

    JTextField customerField;
    JComboBox<String> categoryBox;

    JButton searchBtn;
    JButton bookBtn;
    JButton cancelBtn;
    JButton paymentBtn;
    JButton saveBtn;
    JButton refreshBtn;

    public HotelReservationSystem() {

        setTitle("Advanced Hotel Reservation System");
        setSize(950, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // ================= ROOM DATA =================

        rooms.add(new Room(101, "Standard", 5000));
        rooms.add(new Room(102, "Standard", 5000));
        rooms.add(new Room(201, "Deluxe", 8000));
        rooms.add(new Room(202, "Deluxe", 8000));
        rooms.add(new Room(301, "Suite", 12000));
        rooms.add(new Room(302, "Suite", 12000));

        // ================= TOP PANEL =================

        JPanel topPanel = new JPanel(new GridLayout(2, 3, 10, 10));
        topPanel.setOpaque(true);
        topPanel.setBackground(Color.BLUE);

        customerField = new JTextField();

        categoryBox = new JComboBox<>(
                new String[]{
                        "Standard",
                        "Deluxe",
                        "Suite"
                });

        topPanel.add(new JLabel("Customer Name"));
        topPanel.add(new JLabel("Room Category"));
        topPanel.add(new JLabel(""));

        topPanel.add(customerField);
        topPanel.add(categoryBox);

        searchBtn = new JButton("Search Room");
        topPanel.add(searchBtn);

        // ================= TABLE =================

        String[] columns = {
                "Room No",
                "Category",
                "Price",
                "Status"
        };

        model = new DefaultTableModel(columns, 0);

        table = new JTable(model);
        table.setOpaque(false);

        JScrollPane scrollPane =
                new JScrollPane(table);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);

        // ================= BUTTON PANEL =================

        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(true);
        buttonPanel.setBackground(Color.WHITE);

        bookBtn = new JButton("Book Room");
        cancelBtn = new JButton("Cancel Booking");
        paymentBtn = new JButton("Payment");
        saveBtn = new JButton("Save Records");
        refreshBtn = new JButton("Refresh");

        // Set button colors
        searchBtn.setBackground(Color.YELLOW);
        bookBtn.setBackground(Color.GREEN);
        cancelBtn.setBackground(Color.RED);
        paymentBtn.setBackground(Color.BLUE);
        saveBtn.setBackground(Color.ORANGE);
        refreshBtn.setBackground(Color.CYAN);

        buttonPanel.add(bookBtn);
        buttonPanel.add(cancelBtn);
        buttonPanel.add(paymentBtn);
        buttonPanel.add(saveBtn);
        buttonPanel.add(refreshBtn);

        // ================= LAYOUT =================
        try {
            Image bgImage = ImageIO.read(new File("3.png"));
            BackgroundPanel bgPanel = new BackgroundPanel(bgImage);
            bgPanel.setLayout(new BorderLayout(10, 10));
            bgPanel.add(topPanel, BorderLayout.NORTH);
            bgPanel.add(scrollPane, BorderLayout.CENTER);
            bgPanel.add(buttonPanel, BorderLayout.SOUTH);
            setContentPane(bgPanel);
        } catch (IOException e) {
            setLayout(new BorderLayout(10, 10));
            add(topPanel, BorderLayout.NORTH);
            add(scrollPane, BorderLayout.CENTER);
            add(buttonPanel, BorderLayout.SOUTH);
        }

        // ================= EVENTS =================

        searchBtn.addActionListener(e -> searchRooms());

        bookBtn.addActionListener(e -> bookRoom());

        cancelBtn.addActionListener(e -> cancelBooking());

        paymentBtn.addActionListener(e -> makePayment());

        saveBtn.addActionListener(e -> saveToFile());

        refreshBtn.addActionListener(e -> loadRooms());

        // ================= INITIAL LOAD =================

        loadRooms();

        setVisible(true);
    }

    // ================= LOAD ROOMS =================

    void loadRooms() {

        model.setRowCount(0);

        for (Room r : rooms) {

            model.addRow(new Object[]{
                    r.roomNumber,
                    r.category,
                    r.price,
                    r.booked ? "Booked" : "Available"
            });
        }
    }

    // ================= SEARCH ROOMS =================

    void searchRooms() {

        String category =
                categoryBox.getSelectedItem().toString();

        model.setRowCount(0);

        for (Room r : rooms) {

            if (r.category.equals(category)
                    && !r.booked) {

                model.addRow(new Object[]{
                        r.roomNumber,
                        r.category,
                        r.price,
                        "Available"
                });
            }
        }
    }

    // ================= BOOK ROOM =================

    void bookRoom() {

        int row = table.getSelectedRow();

        if (row < 0) {

            JOptionPane.showMessageDialog(this,
                    "<html><b>Select a room first!</b></html>");

            return;
        }

        String customer =
                customerField.getText();

        if (customer.isEmpty()) {

            JOptionPane.showMessageDialog(this,
                    "<html><b>Enter customer name!</b></html>");

            return;
        }

        int roomNo =
                Integer.parseInt(
                        model.getValueAt(row, 0).toString());

        for (Room r : rooms) {

            if (r.roomNumber == roomNo) {

                if (!r.booked) {

                    r.booked = true;

                    Booking b = new Booking(
                            customer,
                            r.roomNumber,
                            r.category,
                            r.price
                    );

                    bookings.add(b);

                    JOptionPane.showMessageDialog(this,
                            "<html><b>Room Booked Successfully!</b></html>");

                    loadRooms();

                    return;

                } else {

                    JOptionPane.showMessageDialog(this,
                            "<html><b>Room Already Booked!</b></html>");
                }
            }
        }
    }

    // ================= CANCEL BOOKING =================

    void cancelBooking() {

        String input =
                JOptionPane.showInputDialog(
                        this,
                        "Enter Room Number to Cancel:");

        if (input == null) return;

        int roomNo = Integer.parseInt(input);

        for (Room r : rooms) {

            if (r.roomNumber == roomNo) {

                if (r.booked) {

                    r.booked = false;

                    bookings.removeIf(
                            b -> b.roomNumber == roomNo
                    );

                    JOptionPane.showMessageDialog(this,
                            "<html><b>Booking Cancelled!</b></html>");

                    loadRooms();

                    return;
                }
            }
        }

        JOptionPane.showMessageDialog(this,
                "<html><b>Booking Not Found!</b></html>");
    }

    // ================= PAYMENT =================

    void makePayment() {

        int row = table.getSelectedRow();

        if (row < 0) {

            JOptionPane.showMessageDialog(this,
                    "<html><b>Select booked room!</b></html>");

            return;
        }

        String status =
                model.getValueAt(row, 3).toString();

        if (!status.equals("Booked")) {

            JOptionPane.showMessageDialog(this,
                    "<html><b>Room is not booked yet!</b></html>");

            return;
        }

        double amount =
                Double.parseDouble(
                        model.getValueAt(row, 2).toString());

        JOptionPane.showMessageDialog(this,
                "Payment Successful!\nAmount Paid: Rs. "
                        + amount);
    }

    // ================= SAVE FILE =================

    void saveToFile() {

        try (FileWriter writer = new FileWriter("bookings.txt")) {

            for (Booking b : bookings) {

                writer.write(
                        "Customer: " + b.customerName +
                                ", Room: " + b.roomNumber +
                                ", Category: " + b.category +
                                ", Payment: " + b.payment +
                                "\n"
                );
            }

            JOptionPane.showMessageDialog(this,
                    "<html><b>Booking Records Saved!</b></html>");

        } catch (IOException e) {

            JOptionPane.showMessageDialog(this,
                    "<html><b>Error Saving File!</b></html>");
        }
    }

    // ================= MAIN =================

    public static void main(String[] args) {

        new HotelReservationSystem();
    }
}